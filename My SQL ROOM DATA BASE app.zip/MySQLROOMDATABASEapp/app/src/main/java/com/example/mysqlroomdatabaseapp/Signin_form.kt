package com.example.mysqlroomdatabaseapp

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast


lateinit var email:EditText
lateinit var password:EditText
lateinit var login:Button
class Signin_form : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signin_form)
        email=findViewById(R.id.editTextTextEmailAddress)
        password=findViewById(R.id.editTextTextPassword1)
        login=findViewById(R.id.button_login)
        var textV:TextView=findViewById(R.id.textView2)
        textV.setOnClickListener(View.OnClickListener {
            startActivity(Intent(this@Signin_form,Signout_form::class.java))
            finish()
        })

        login.setOnClickListener {
            val dbHelper = DbHelper(applicationContext)
            val (_, _, email1, password1) = dbHelper.getUserDetails(email.text.toString())
            // Toast.makeText(LoginPage.this, profile.getEmail()+"/n"+profile.getName()+"/n"+profile.getPassword(), Toast.LENGTH_SHORT).show();
            if (password1 == password.text.toString()) {
                Toast.makeText(this@Signin_form, "Login Successfull", Toast.LENGTH_SHORT).show()
                val intent = Intent(this@Signin_form, MainActivity::class.java)
                //  Toast.makeText(LoginPage.this, profile.getEmail(), Toast.LENGTH_SHORT).show();
                intent.putExtra("email", email1)
                startActivity(intent)
                finish()
                //finish();
            } else {
                Toast.makeText(this@Signin_form, "Invalid Id or Password", Toast.LENGTH_SHORT).show()
            }
        }
    }
}