package com.example.mysqlroomdatabaseapp

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.Button
import android.widget.TextView

lateinit var btn:Button
lateinit var textv:TextView
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btn=findViewById(
            R.id.logout
        )
        textv=findViewById(R.id.textView3)

        val dbHelper = DbHelper(applicationContext)
        val intent = intent
        val email = intent.getStringExtra("email")
        val (_, name) = dbHelper.getUserDetails(email!!)
        com.example.mysqlroomdatabaseapp.textv.text="Welcome -: $name"
        btn.setOnClickListener(View.OnClickListener {
            startActivity(Intent(this@MainActivity,Signin_form::class.java))
        })
    }
}