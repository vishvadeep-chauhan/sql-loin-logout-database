package com.example.mysqlroomdatabaseapp

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast


class Signout_form : AppCompatActivity() {
    lateinit var name:EditText
    lateinit var email:EditText
    lateinit var password:EditText
    lateinit var register:Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signout_form)

        name=findViewById(R.id.editTextTextPersonName)
        email=findViewById(R.id.editTextTextEmailAddress2)
        password=findViewById(R.id.editTextTextPassword)
        register=findViewById(R.id.register_btn)

        findViewById<TextView>(R.id.textView001).setOnClickListener(View.OnClickListener {
            startActivity(Intent(this@Signout_form,Signin_form::class.java))
            finish()
        })
        register.setOnClickListener {
            val dbHelper = DbHelper(applicationContext)
            val profile = Profile(1, "","","")
            profile.name = name.text.toString()
            profile.email = email.text.toString()
            profile.password = password.text.toString()
            val res = dbHelper.addUser(profile)
            if (res) {
                Toast.makeText(this@Signout_form, "Account Created", Toast.LENGTH_SHORT).show()
                val intent = Intent(this@Signout_form, MainActivity::class.java)
                intent.putExtra("email", email.text.toString())
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this@Signout_form, "Something went wrong!", Toast.LENGTH_SHORT)
                    .show()
            }
        }


    }
}