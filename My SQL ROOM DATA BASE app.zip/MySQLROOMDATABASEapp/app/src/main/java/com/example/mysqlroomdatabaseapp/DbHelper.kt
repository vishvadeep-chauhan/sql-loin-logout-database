package com.example.mysqlroomdatabaseapp

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.support.annotation.Nullable


class DbHelper(@Nullable context: Context?) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
    override fun onCreate(sqLiteDatabase: SQLiteDatabase) {
        val query =
            ("CREATE TABLE " + TABLE_NAME + "(" + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + USER_NAME
                    + " TEXT," + USER_EMAIL + " TEXT," + USER_PASSWORD + " TEXT" + ")")
        sqLiteDatabase.execSQL(query)
    }

    override fun onUpgrade(sqLiteDatabase: SQLiteDatabase, i: Int, i1: Int) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME)
        onCreate(sqLiteDatabase)
    }

    fun addUser(profile: Profile): Boolean {
        val database = this.writableDatabase
        val values = ContentValues()
        values.put(USER_NAME, profile.name)
        values.put(USER_EMAIL, profile.email)
        values.put(USER_PASSWORD, profile.password)
        val res = database.insert(TABLE_NAME, null, values)
        database.close()
        return if (res > 0) {
            true
        } else {
            false
        }
    }

    fun getUserDetails(email: String): Profile {
        val database = this.readableDatabase
        val cursor: Cursor? = database.query(
            TABLE_NAME,
            arrayOf(KEY_ID, USER_NAME, USER_EMAIL, USER_PASSWORD),
            USER_EMAIL + "=?",
            arrayOf(email),
            null,
            null,
            null,
            null
        )
        val profile = Profile(1,"abc","abc","123")
        if (cursor != null) {
            cursor.moveToFirst()
            profile.name = cursor.getString(1)
            profile.email = cursor.getString(2)
            profile.password = cursor.getString(3)
        }
        return profile
    }

    companion object {
        private const val DATABASE_VERSION = 1
        private const val DATABASE_NAME = "demo.db"
        private const val TABLE_NAME = "users"
        private const val KEY_ID = "id"
        private const val USER_NAME = "name"
        private const val USER_EMAIL = "email"
        private const val USER_PASSWORD = "password"
    }
}


