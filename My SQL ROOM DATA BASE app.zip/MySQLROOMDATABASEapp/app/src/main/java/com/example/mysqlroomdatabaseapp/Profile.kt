package com.example.mysqlroomdatabaseapp

data class Profile(var id:Int,var name:String,var email:String,var password:String) {


}